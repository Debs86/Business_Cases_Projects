# import libraries
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

# create function that will print the classification for a new customer
def predict(new_customer_file):

    # read new customer .csv file
    new_customer = pd.read_csv(new_customer_file)

    # import the treated .csv file that was used to train the model
    data = pd.read_csv('df_cluster_standard.csv')

    # Preparing the data
    X = data.drop(columns=['kmeans_standard_labels'])
    y = data.kmeans_standard_labels

    # Get customer data
    customer = pd.read_csv('customer.csv')
    customer.drop(columns='Unnamed: 0', inplace=True)
    customer = customer.set_index('Custid')
    customer['Avg_ticket'] = np.round(customer['Monetary']/customer['Freq'],2)
    customer = customer[X.columns.to_list()]

    # Get raw data
    raw_data = pd.read_excel('WonderfulWinesoftheWorld.xlsx')
    raw_data = raw_data.set_index('Custid')
    raw_data['Avg_ticket'] = np.round(raw_data['Monetary']/raw_data['Freq'],2)
    raw_data = raw_data[X.columns.to_list()]

    # Define the scaler, fit and scale data
    scaler = StandardScaler()
    scaler.fit(raw_data)
    customer_scaled = scaler.transform(customer)

    # Fit the decision tree
    dt = DecisionTreeClassifier(random_state=42, max_depth = 12,criterion='entropy')
    dt.fit(X, y)

    # Predict result
    result = dt.predict(customer)[0]

    message = "The customer belongs to the cluster {}.".format(result)

    return message